export default function Map() {
    return <h1>About</h1>
  }
  