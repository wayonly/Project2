export default function Pricing() {
    return <h1>Service</h1>
  }
  